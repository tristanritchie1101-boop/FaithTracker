# FaithTracker (Android, Jetpack Compose)

This zip contains a complete Android Studio project that you can upload to GitHub and build to an APK from your phone.

## Build in the cloud (phone-only)

1. Create a repo at https://github.com/new named `FaithTracker`.
2. Upload **all** files/folders from this zip (including the `app` folder and `settings.gradle.kts`).
3. Create `.github/workflows/android.yml` with:

```yaml
name: Build Android APK
on: { workflow_dispatch: {} }
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v3
      - name: Build debug APK
        run: ./gradlew assembleDebug
      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: FaithTracker-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

4. Go to the **Actions** tab → run the workflow → download the **APK** artifact → install on your phone.
5. If blocked, enable **Install unknown apps** for your browser / My Files app.

## Features
- Daily checklist tied to Scripture
- Journal (per day)
- Streak tracking (counts day when >= 3 practices)
- Home screen widget with interactive toggles
- Stats (7 & 30 days)
- Weekly Review + PDF export

Enjoy!
