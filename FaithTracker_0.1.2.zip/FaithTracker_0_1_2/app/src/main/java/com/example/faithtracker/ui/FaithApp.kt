
package com.example.faithtracker.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.SelfImprovement
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.VolunteerActivism
import androidx.compose.material.icons.outlined.PeopleAlt
import androidx.compose.material.icons.outlined.NightlightRound
import androidx.compose.material.icons.outlined.CompassCalibration
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.faithtracker.viewmodel.FaithViewModel
import java.time.LocalDate

@Composable
fun FaithApp(vm: FaithViewModel = viewModel()) {
    val ctx = LocalContext.current
    val dynamic = if (android.os.Build.VERSION.SDK_INT >= 31) {
        val dark = isSystemInDarkTheme()
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else null
    val colors = dynamic ?: if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()

    val gradient = if (isSystemInDarkTheme())
        Brush.linearGradient(listOf(Color(0xFF111525), Color(0xFF1B2440)))
    else
        Brush.linearGradient(listOf(Color(0xFFF7FAFF), Color(0xFFEAF2FF)))

    MaterialTheme(colorScheme = colors) {
        Scaffold(topBar = { TopAppBar(title = { Text("FaithTracker") }) }, containerColor = Color.Transparent) { pad ->
            Box(Modifier.fillMaxSize().background(gradient).padding(pad)) {
                HomeDashboard(vm)
            }
        }
    }
}

@Composable
private fun HomeDashboard(vm: FaithViewModel) {
    val state by vm.state.collectAsState()
    val verse = remember {
        val verses = listOf(
            "2 Tim 3:16 — All Scripture is God‑breathed and useful…",
            "Ps 119:105 — Your word is a lamp to my feet…",
            "1 Thes 5:17 — Pray without ceasing.",
            "Jas 5:16 — The prayer of a righteous person is powerful…",
            "Jn 4:24 — Worship in Spirit and truth.",
            "Ps 46:10 — Be still and know that I am God."
        )
        val i = LocalDate.now().dayOfYear % verses.size
        verses[i]
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header with progress ring + verse of the day
        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProgressRing(progress = state.completedCount()/6f, size = 72.dp, stroke = 10.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Verse of the day", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    Text(verse)
                }
            }
        }

        HabitRow(Icons.Outlined.LibraryBooks, "Word", "2 Tim 3:16; Ps 119:105", state.word) { vm.toggle("word") }
        HabitRow(Icons.Outlined.SelfImprovement, "Prayer", "1 Thes 5:17; Jas 5:16", state.prayer) { vm.toggle("prayer") }
        HabitRow(Icons.Outlined.VolunteerActivism, "Worship", "Jn 4:24; Ps 46:10", state.worship) { vm.toggle("worship") }
        HabitRow(Icons.Outlined.PeopleAlt, "Fellowship", "Prov 27:17; Heb 10:24–25", state.fellowship) { vm.toggle("fellowship") }
        HabitRow(Icons.Outlined.NightlightRound, "Rest / Sabbath", "Ps 46:10", state.rest) { vm.toggle("rest") }
        HabitRow(Icons.Outlined.CompassCalibration, "Reflection", "Ps 139:23; 2 Cor 13:5", state.reflection) { vm.toggle("reflection") }
        Text("Tap to toggle — saved instantly.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
    }
}

@Composable
private fun ProgressRing(progress: Float, size: Dp, stroke: Dp) {
    val anim by animateFloatAsState(targetValue = progress.coerceIn(0f,1f))
    Canvas(Modifier.size(size)) {
        val s = size.minDimension.toPx()
        val st = stroke.toPx()
        // background track
        drawArc(
            color = MaterialTheme.colorScheme.surfaceVariant,
            startAngle = 0f, sweepAngle = 360f, useCenter = false,
            topLeft = Offset(st/2, st/2),
            size = Size(s - st, s - st),
            style = Stroke(width = st, cap = StrokeCap.Round)
        )
        // progress
        drawArc(
            color = MaterialTheme.colorScheme.primary,
            startAngle = -90f, sweepAngle = 360f * anim, useCenter = false,
            topLeft = Offset(st/2, st/2),
            size = Size(s - st, s - st),
            style = Stroke(width = st, cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun HabitRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            }
            Switch(checked = checked, onCheckedChange = { onToggle() })
        }
    }
}
