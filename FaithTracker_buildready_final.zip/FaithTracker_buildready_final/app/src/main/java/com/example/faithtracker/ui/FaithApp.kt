
package com.example.faithtracker.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun FaithApp() {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Text("FaithTracker")
        }
    }
}
