
package com.example.faithtracker.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val Context.dataStore by preferencesDataStore(name = "faith_prefs")

class Prefs(private val context: Context) {
    private fun key(name: String, date: LocalDate): Preferences.Key<Boolean> {
        val d = date.format(DateTimeFormatter.ISO_DATE)
        return booleanPreferencesKey("${name}_$d")
    }
    suspend fun set(name: String, date: LocalDate, value: Boolean) {
        context.dataStore.edit { it[key(name, date)] = value }
    }
    fun get(name: String, date: LocalDate): Flow<Boolean> =
        context.dataStore.data.map { it[key(name, date)] ?: false }
}
