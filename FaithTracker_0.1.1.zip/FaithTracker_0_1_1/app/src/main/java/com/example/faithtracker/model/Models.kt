
package com.example.faithtracker.model

data class DailyState(
    val word: Boolean = false,
    val prayer: Boolean = false,
    val worship: Boolean = false,
    val fellowship: Boolean = false,
    val rest: Boolean = false,
    val reflection: Boolean = false,
) {
    fun completedCount(): Int = listOf(word, prayer, worship, fellowship, rest, reflection).count { it }
}
