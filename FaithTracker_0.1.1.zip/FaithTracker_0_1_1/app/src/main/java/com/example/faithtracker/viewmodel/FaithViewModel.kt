
package com.example.faithtracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.faithtracker.data.Prefs
import com.example.faithtracker.model.DailyState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.time.LocalDate

class FaithViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    val today: LocalDate = LocalDate.now()

    private val _state = MutableStateFlow(DailyState())
    val state: StateFlow<DailyState> = _state

    init {
        viewModelScope.launch {
            combine(
                prefs.get("word", today),
                prefs.get("prayer", today),
                prefs.get("worship", today),
                prefs.get("fellowship", today),
                prefs.get("rest", today),
                prefs.get("reflection", today)
            ) { word, prayer, worship, fellowship, rest, reflection ->
                DailyState(word, prayer, worship, fellowship, rest, reflection)
            }.collect { _state.value = it }
        }
    }

    fun toggle(name: String) {
        val cur = _state.value
        val updated = when (name) {
            "word" -> cur.copy(word = !cur.word)
            "prayer" -> cur.copy(prayer = !cur.prayer)
            "worship" -> cur.copy(worship = !cur.worship)
            "fellowship" -> cur.copy(fellowship = !cur.fellowship)
            "rest" -> cur.copy(rest = !cur.rest)
            "reflection" -> cur.copy(reflection = !cur.reflection)
            else -> cur
        }
        _state.value = updated
        viewModelScope.launch {
            val v = when (name) {
                "word" -> updated.word
                "prayer" -> updated.prayer
                "worship" -> updated.worship
                "fellowship" -> updated.fellowship
                "rest" -> updated.rest
                "reflection" -> updated.reflection
                else -> false
            }
            prefs.set(name, today, v)
        }
    }
}
