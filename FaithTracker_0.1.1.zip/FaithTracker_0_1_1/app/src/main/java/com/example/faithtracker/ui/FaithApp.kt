
package com.example.faithtracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.SelfImprovement
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.VolunteerActivism
import androidx.compose.material.icons.outlined.PeopleAlt
import androidx.compose.material.icons.outlined.NightlightRound
import androidx.compose.material.icons.outlined.CompassCalibration
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.faithtracker.viewmodel.FaithViewModel

@Composable
fun FaithApp(vm: FaithViewModel = viewModel()) {
    val gradient = Brush.linearGradient(
        colors = listOf(Color(0xFFF7FAFF), Color(0xFFEAF2FF)),
        start = Offset.Zero,
        end = Offset.Infinite
    )
    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("FaithTracker") }) },
            containerColor = Color.Transparent
        ) { pad ->
            Box(
                Modifier
                    .fillMaxSize()
                    .background(gradient)
                    .padding(pad)
            ) {
                HabitDashboard(vm)
            }
        }
    }
}

@Composable
private fun HabitDashboard(vm: FaithViewModel) {
    val state by vm.state.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Today completed: ${state.completedCount()} / 6", style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(progress = state.completedCount()/6f, modifier = Modifier.fillMaxWidth())
            }
        }

        HabitRow(Icons.Outlined.LibraryBooks, "Word (2 Tim 3:16; Ps 119:105)", state.word) { vm.toggle("word") }
        HabitRow(Icons.Outlined.SelfImprovement, "Prayer (1 Thes 5:17; Jas 5:16)", state.prayer) { vm.toggle("prayer") }
        HabitRow(Icons.Outlined.VolunteerActivism, "Worship (Jn 4:24; Ps 46:10)", state.worship) { vm.toggle("worship") }
        HabitRow(Icons.Outlined.PeopleAlt, "Fellowship (Prov 27:17; Heb 10:24–25)", state.fellowship) { vm.toggle("fellowship") }
        HabitRow(Icons.Outlined.NightlightRound, "Rest / Sabbath (Ps 46:10)", state.rest) { vm.toggle("rest") }
        HabitRow(Icons.Outlined.CompassCalibration, "Reflection (Ps 139:23; 2 Cor 13:5)", state.reflection) { vm.toggle("reflection") }

        Spacer(Modifier.height(8.dp))
        Text("Tap to toggle — saved instantly.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun HabitRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, checked: Boolean, onToggle: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = if (checked) Color(0xFF2B6CB0) else Color(0xFF7AA7FF))
            Text(label, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = { onToggle() })
        }
    }
}
