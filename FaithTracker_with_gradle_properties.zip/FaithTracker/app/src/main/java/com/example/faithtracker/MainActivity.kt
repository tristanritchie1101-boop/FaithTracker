package com.example.faithtracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.faithtracker.ui.FaithApp

class MainActivity: ComponentActivity(){
  override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { FaithApp() } }
}
