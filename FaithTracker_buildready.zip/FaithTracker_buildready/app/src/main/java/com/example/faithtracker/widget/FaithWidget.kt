package com.example.faithtracker.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.faithtracker.MainActivity
import com.example.faithtracker.R
import com.example.faithtracker.data.Prefs
import com.example.faithtracker.model.DailyState
import com.google.gson.Gson
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.time.LocalDate

class FaithWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) updateAppWidget(context, appWidgetManager, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH -> refreshAll(context)
            ACTION_TOGGLE -> {
                val field = intent.getStringExtra(EXTRA_FIELD) ?: return
                toggleField(context, field)
                refreshAll(context)
            }
        }
    }

    private fun refreshAll(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        val ids = mgr.getAppWidgetIds(ComponentName(context, FaithWidget::class.java))
        onUpdate(context, mgr, ids)
    }

    companion object {
        const val ACTION_REFRESH = "com.example.faithtracker.widget.REFRESH"
        const val ACTION_TOGGLE  = "com.example.faithtracker.widget.TOGGLE"
        const val EXTRA_FIELD    = "field"

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_faith_tracker)

            val prefs = Prefs(context)
            val today = LocalDate.now()
            val gson = Gson()
            val state: DailyState = runBlocking {
                val json = prefs.readDayState(today).first()
                json?.let { gson.fromJson(it, DailyState::class.java) } ?: DailyState()
            }

            val completed = state.completedCount()
            views.setTextViewText(R.id.widget_title, "FaithTracker")
            views.setTextViewText(R.id.widget_progress_text, "Today: $completed / 6")
            views.setProgressBar(R.id.widget_progress_bar, 6, completed, false)

            fun flag(b: Boolean) = if (b) "✅" else "⬜"
            views.setTextViewText(R.id.btn_word,    "${flag(state.word)} Word")
            views.setTextViewText(R.id.btn_prayer,  "${flag(state.prayer)} Prayer")
            views.setTextViewText(R.id.btn_worship, "${flag(state.worship)} Worship")
            views.setTextViewText(R.id.btn_fellow,  "${flag(state.fellowship)} Fellow.")
            views.setTextViewText(R.id.btn_rest,    "${flag(state.rest)} Rest")
            views.setTextViewText(R.id.btn_reflect, "${flag(state.reflection)} Reflect")

            val openPI = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.widget_root, openPI)

            val refreshPI = PendingIntent.getBroadcast(
                context, 1,
                Intent(context, FaithWidget::class.java).apply { action = ACTION_REFRESH },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPI)

            fun togglePI(field: String, req: Int) = PendingIntent.getBroadcast(
                context, req,
                Intent(context, FaithWidget::class.java).apply {
                    action = ACTION_TOGGLE
                    putExtra(EXTRA_FIELD, field)
                },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            views.setOnClickPendingIntent(R.id.btn_word,    togglePI("word", 101))
            views.setOnClickPendingIntent(R.id.btn_prayer,  togglePI("prayer", 102))
            views.setOnClickPendingIntent(R.id.btn_worship, togglePI("worship", 103))
            views.setOnClickPendingIntent(R.id.btn_fellow,  togglePI("fellowship", 104))
            views.setOnClickPendingIntent(R.id.btn_rest,    togglePI("rest", 105))
            views.setOnClickPendingIntent(R.id.btn_reflect, togglePI("reflection", 106))

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun toggleField(context: Context, field: String) {
            val prefs = Prefs(context)
            val today = LocalDate.now()
            val gson = Gson()
            runBlocking {
                val json = prefs.readDayState(today).first()
                val current = json?.let { gson.fromJson(it, DailyState::class.java) } ?: DailyState()
                val updated = when (field) {
                    "word" -> current.copy(word = !current.word)
                    "prayer" -> current.copy(prayer = !current.prayer)
                    "worship" -> current.copy(worship = !current.worship)
                    "fellowship" -> current.copy(fellowship = !current.fellowship)
                    "rest" -> current.copy(rest = !current.rest)
                    "reflection" -> current.copy(reflection = !current.reflection)
                    else -> current
                }
                prefs.saveDayState(today, gson.toJson(updated))
            }
        }
    }
}
