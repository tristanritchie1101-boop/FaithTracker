package com.example.faithtracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.faithtracker.data.Prefs
import com.example.faithtracker.model.DailyState
import com.google.gson.Gson
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.max

class FaithViewModel(app: Application): AndroidViewModel(app) {
    private val prefs = Prefs(app)
    val today: LocalDate = LocalDate.now()
    private val gson = Gson()

    private val _journal = MutableStateFlow("")
    val journal: StateFlow<String> = _journal

    private val _state = MutableStateFlow(DailyState())
    val state: StateFlow<DailyState> = _state

    val streak: StateFlow<Int> = prefs.streak().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    data class Stats(
        val daysDone: Int = 0,
        val completionRate: Float = 0f,
        val practiceRates: Map<String, Float> = emptyMap()
    )
    private val _stats7 = MutableStateFlow(Stats())
    val stats7: StateFlow<Stats> = _stats7.asStateFlow()
    private val _stats30 = MutableStateFlow(Stats())
    val stats30: StateFlow<Stats> = _stats30.asStateFlow()

    data class WeeklyReview(
        val daysDone: Int = 0,
        val practiceCounts: Map<String, Int> = emptyMap(),
        val longestStreak: Int = 0,
        val currentStreak: Int = 0,
    )
    private val _weeklyReview = MutableStateFlow(WeeklyReview())
    val weeklyReview: StateFlow<WeeklyReview> = _weeklyReview.asStateFlow()

    init {
        viewModelScope.launch {
            val json = prefs.readDayState(today).first()
            _state.value = json?.let { gson.fromJson(it, DailyState::class.java) } ?: DailyState()
            val j = prefs.readJournal(today).first()
            _journal.value = j ?: ""
        }
        viewModelScope.launch {
            loadStatsIntoFlows()
            _weeklyReview.value = computeWeeklyReview()
        }
    }

    fun toggle(field: String) {
        _state.value = when(field) {
            "word" -> _state.value.copy(word = !_state.value.word)
            "prayer" -> _state.value.copy(prayer = !_state.value.prayer)
            "worship" -> _state.value.copy(worship = !_state.value.worship)
            "fellowship" -> _state.value.copy(fellowship = !_state.value.fellowship)
            "rest" -> _state.value.copy(rest = !_state.value.rest)
            "reflection" -> _state.value.copy(reflection = !_state.value.reflection)
            else -> _state.value
        }
    }

    fun updateCharacterFocus(text: String) { _state.value = _state.value.copy(characterFocus = text) }
    fun updateJournal(text: String) { _journal.value = text }

    fun saveToday() {
        viewModelScope.launch {
            val json = gson.toJson(_state.value)
            prefs.saveDayState(today, json)
            prefs.saveJournal(today, _journal.value)

            val completed = _state.value.completedCount()
            val curStreak = streak.value
            if (completed >= 3) {
                prefs.setStreak(curStreak + 1)
            } else if (curStreak > 0) {
                prefs.setStreak(0)
            }
            loadStatsIntoFlows()
            _weeklyReview.value = computeWeeklyReview()
        }
    }

    private suspend fun loadStatsIntoFlows() {
        _stats7.value = computeStats(daysBack = 7)
        _stats30.value = computeStats(daysBack = 30)
    }

    private suspend fun computeStats(daysBack: Int): Stats {
        val today = LocalDate.now()
        var daysDone = 0
        var word = 0; var prayer = 0; var worship = 0; var fellowship = 0; var rest = 0; var reflection = 0

        for (i in 0 until daysBack) {
            val d = today.minusDays(i.toLong())
            val json = prefs.readDayState(d).first()
            val st = json?.let { gson.fromJson(it, DailyState::class.java) }
            if (st != null) {
                if (st.completedCount() >= 3) daysDone++
                if (st.word) word++
                if (st.prayer) prayer++
                if (st.worship) worship++
                if (st.fellowship) fellowship++
                if (st.rest) rest++
                if (st.reflection) reflection++
            }
        }
        val denom = daysBack.coerceAtLeast(1)
        val rate = daysDone.toFloat() / denom
        val practices = mapOf(
            "Word" to word.toFloat() / denom,
            "Prayer" to prayer.toFloat() / denom,
            "Worship" to worship.toFloat() / denom,
            "Fellowship" to fellowship.toFloat() / denom,
            "Rest" to rest.toFloat() / denom,
            "Reflection" to reflection.toFloat() / denom,
        )
        return Stats(daysDone = daysDone, completionRate = rate, practiceRates = practices)
    }

    private suspend fun computeWeeklyReview(): WeeklyReview {
        val today = LocalDate.now()
        var daysDone = 0
        var word = 0; var prayer = 0; var worship = 0; var fellowship = 0; var rest = 0; var reflection = 0
        var longest = 0; var current = 0
        var running = 0
        for (i in 0 until 30) {
            val d = today.minusDays(i.toLong())
            val json = prefs.readDayState(d).first()
            val st = json?.let { gson.fromJson(it, DailyState::class.java) }
            if (i < 7 && st != null) {
                if (st.completedCount() >= 3) daysDone++
                if (st.word) word++
                if (st.prayer) prayer++
                if (st.worship) worship++
                if (st.fellowship) fellowship++
                if (st.rest) rest++
                if (st.reflection) reflection++
            }
            val win = (st?.completedCount() ?: 0) >= 3
            if (win) { running += 1; longest = max(longest, running) } else { running = 0 }
            if (i == 0) current = running
        }
        return WeeklyReview(
            daysDone = daysDone,
            practiceCounts = mapOf(
                "Word" to word, "Prayer" to prayer, "Worship" to worship,
                "Fellowship" to fellowship, "Rest" to rest, "Reflection" to reflection
            ),
            longestStreak = longest,
            currentStreak = current
        )
    }
}
