package com.example.faithtracker.ui

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.faithtracker.notifications.ReminderReceiver
import com.example.faithtracker.viewmodel.FaithViewModel
import com.example.faithtracker.model.VERSES
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Description

@Composable
fun FaithApp(vm: FaithViewModel = viewModel()) {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = darkColorScheme()) {
        NavHost(navController = nav, startDestination = "home") {
            composable("home") { HomeScreen(nav, vm) }
            composable("journal") { JournalScreen(nav, vm) }
            composable("verses") { VerseListScreen(nav) }
            composable("stats") { StatsScreen(onBack = { nav.popBackStack() }) }
            composable("review") { ReviewScreen(onBack = { nav.popBackStack() }) }
            composable("settings") { SettingsScreen(nav) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(nav: NavHostController, vm: FaithViewModel) {
    val date = vm.today
    val state by vm.state.collectAsState()
    val streak by vm.streak.collectAsState()
    val verseOfDay = remember(date) { VERSES[(date.dayOfYear) % VERSES.size] }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("FaithTracker — ${date}") }, actions = {
                TextButton(onClick = { nav.navigate("verses") }) { Text("Verses") }
                TextButton(onClick = { nav.navigate("journal") }) { Text("Journal") }
                IconButton(onClick = { nav.navigate("stats") }) { Icon(Icons.Filled.BarChart, contentDescription = "Stats") }
                IconButton(onClick = { nav.navigate("review") }) { Icon(Icons.Filled.Description, contentDescription = "Weekly Review") }
                TextButton(onClick = { nav.navigate("settings") }) { Text("Settings") }
            })
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(verseOfDay.text, style = MaterialTheme.typography.titleMedium)
                        Text("— ${verseOfDay.ref}", textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item {
                ProgressCard(streak = streak, completed = state.completedCount())
            }
            item { Checklist(vm) }
        }
    }
}

@Composable
fun ProgressCard(streak: Int, completed: Int) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Today completed: $completed / 6")
            LinearProgressIndicator(progress = (completed/6f), Modifier.fillMaxWidth().padding(top = 8.dp))
            Spacer(Modifier.height(8.dp))
            Text("Streak: $streak days")
        }
    }
}

@Composable
fun Checklist(vm: FaithViewModel) {
    val state by vm.state.collectAsState()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LabeledCheck("Word (2 Tim 3:16; Ps 119:105)", state.word) { vm.toggle("word") }
            LabeledCheck("Prayer (1 Thes 5:17; Jas 5:16)", state.prayer) { vm.toggle("prayer") }
            LabeledCheck("Worship (John 4:24; Ps 46:10)", state.worship) { vm.toggle("worship") }
            LabeledCheck("Fellowship (Prov 27:17; Heb 10:24-25)", state.fellowship) { vm.toggle("fellowship") }
            LabeledCheck("Rest / Sabbath (Ps 46:10)", state.rest) { vm.toggle("rest") }
            LabeledCheck("Reflection (Ps 139:23; 2 Cor 13:5)", state.reflection) { vm.toggle("reflection") }
            OutlinedTextField(
                value = state.characterFocus,
                onValueChange = { vm.updateCharacterFocus(it) },
                label = { Text("Character focus (Jn 14:15; Jas 2:17)") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { vm.saveToday() }, modifier = Modifier.align(Alignment.End)) { Text("Save") }
        }
    }
}

@Composable
fun LabeledCheck(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(nav: NavHostController, vm: FaithViewModel) {
    val text by vm.journal.collectAsState()
    Scaffold(topBar = { TopAppBar(title = { Text("Journal") }, navigationIcon = {
        TextButton(onClick = { nav.popBackStack() }) { Text("Back") }
    }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { vm.updateJournal(it) },
                label = { Text("Talk to God about today…") },
                modifier = Modifier.fillMaxWidth().weight(1f, false),
                minLines = 8
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.saveToday() }, modifier = Modifier.align(Alignment.End)) { Text("Save") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VerseListScreen(nav: NavHostController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Core Verses") }, navigationIcon = {
        TextButton(onClick = { nav.popBackStack() }) { Text("Back") }
    }) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(VERSES) { v ->
                Card { Column(Modifier.padding(16.dp)) { Text(v.text); Spacer(Modifier.height(4.dp)); Text("— ${v.ref}") } }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    var hour by remember { mutableStateOf(7) }
    var minute by remember { mutableStateOf(0) }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings & Reminders") }, navigationIcon = {
        TextButton(onClick = { nav.popBackStack() }) { Text("Back") }
    }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Daily reminder (optional)")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = hour.toString(), onValueChange = { it.toIntOrNull()?.let { h -> hour = h.coerceIn(0,23) } }, label = { Text("Hour (0-23)") }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(value = minute.toString(), onValueChange = { it.toIntOrNull()?.let { m -> minute = m.coerceIn(0,59) } }, label = { Text("Min (0-59)") }, modifier = Modifier.weight(1f))
            }
            Button(onClick = { scheduleReminder(ctx, hour, minute) }) { Text("Enable / Update Reminder") }
            Text("Reminders nudge you to pray, read, and reflect — the app won’t spam you (promise).")
        }
    }
}

private fun scheduleReminder(ctx: Context, hour: Int, minute: Int) {
    val mgr = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(ctx, ReminderReceiver::class.java)
    val pi = PendingIntent.getBroadcast(ctx, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val now = LocalDate.now()
    val trigger = now.atTime(LocalTime.of(hour, minute)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        mgr.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
    } else {
        mgr.setExact(AlarmManager.RTC_WAKEUP, trigger, pi)
    }
}
