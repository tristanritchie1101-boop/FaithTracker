package com.example.faithtracker.ui

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.faithtracker.viewmodel.FaithViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(onBack: () -> Unit, vm: FaithViewModel = viewModel()) {
    val review by vm.weeklyReview.collectAsState()
    val ctx = LocalContext.current

    Scaffold(topBar = { TopAppBar(title = { Text("Weekly Review") }, navigationIcon = {
        TextButton(onClick = onBack) { Text("Back") }
    }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Summary (last 7 days)", style = MaterialTheme.typography.titleMedium)
            Text("Completed days: ${review.daysDone}/7")
            review.practiceCounts.forEach { (k,v) -> Text("$k: $v/7") }
            Text("Longest streak: ${review.longestStreak} days")
            Text("Current streak: ${review.currentStreak} days")
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                val file = createWeeklyPdf(ctx, review)
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(share, "Share Weekly Review PDF"))
            }) { Text("Export PDF & Share") }
        }
    }
}

private fun createWeeklyPdf(ctx: android.content.Context, review: FaithViewModel.WeeklyReview): File {
    val pdf = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(612, 792, 1).create()
    val page = pdf.startPage(pageInfo)
    val c = page.canvas
    val paint = Paint().apply { textSize = 16f }
    var y = 40f
    c.drawText("FaithTracker — Weekly Review", 40f, y, paint); y += 28f
    paint.textSize = 12f
    c.drawText("Completed days: ${review.daysDone}/7", 40f, y, paint); y += 20f
    review.practiceCounts.forEach { (k,v) -> c.drawText("$k: $v/7", 40f, y, paint); y += 18f }
    c.drawText("Longest streak: ${review.longestStreak}", 40f, y, paint); y += 18f
    c.drawText("Current streak: ${review.currentStreak}", 40f, y, paint); y += 18f
    pdf.finishPage(page)

    val outFile = File(ctx.cacheDir, "faith_weekly_review.pdf")
    outFile.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    return outFile
}
