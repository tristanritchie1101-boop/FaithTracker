package com.example.faithtracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.faithtracker.viewmodel.FaithViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(vm: FaithViewModel = viewModel(), onBack: () -> Unit) {
    val stats7 by vm.stats7.collectAsState()
    val stats30 by vm.stats30.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("Statistics") }, navigationIcon = {
        TextButton(onClick = onBack) { Text("Back") }
    }) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item { StatSummaryCard("Last 7 days", stats7.completionRate, stats7.daysDone, 7) }
            item { StatBars("Practice completion (7d)", stats7.practiceRates) }
            item { Divider() }
            item { StatSummaryCard("Last 30 days", stats30.completionRate, stats30.daysDone, 30) }
            item { StatBars("Practice completion (30d)", stats30.practiceRates) }
        }
    }
}

@Composable
private fun StatSummaryCard(title: String, rate: Float, daysDone: Int, window: Int) {
    Card { Column(Modifier.padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = rate)
        Spacer(Modifier.height(8.dp))
        Text("Completed days: $daysDone / $window")
        Text("Completion rate: ${(rate*100).toInt()}%")
    } }
}

@Composable
private fun StatBars(caption: String, practiceRates: Map<String, Float>) {
    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(caption, style = MaterialTheme.typography.titleMedium)
        practiceRates.forEach { (label, rate) ->
            Text(label)
            LinearProgressIndicator(progress = rate, modifier = Modifier.fillMaxWidth())
        }
    } }
}
