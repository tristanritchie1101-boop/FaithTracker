package com.example.faithtracker.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private val Context.dataStore by preferencesDataStore(name = "faith_prefs")

object PrefKeys {
    fun dayStateKey(date: LocalDate) = stringPreferencesKey("${date}:state")
    fun dayJournalKey(date: LocalDate) = stringPreferencesKey("${date}:journal")
    val streakKey = intPreferencesKey("streak")
}

class Prefs(private val context: Context) {
    suspend fun saveDayState(date: LocalDate, json: String) {
        context.dataStore.edit { it[PrefKeys.dayStateKey(date)] = json }
    }
    fun readDayState(date: LocalDate): Flow<String?> =
        context.dataStore.data.map { it[PrefKeys.dayStateKey(date)] }

    suspend fun saveJournal(date: LocalDate, text: String) {
        context.dataStore.edit { it[PrefKeys.dayJournalKey(date)] = text }
    }
    fun readJournal(date: LocalDate): Flow<String?> =
        context.dataStore.data.map { it[PrefKeys.dayJournalKey(date)] }

    suspend fun setStreak(value: Int) {
        context.dataStore.edit { it[PrefKeys.streakKey] = value }
    }
    fun streak(): Flow<Int> = context.dataStore.data.map { it[PrefKeys.streakKey] ?: 0 }
}
