package com.example.faithtracker.model

data class DailyState(
    val word: Boolean = false,
    val prayer: Boolean = false,
    val worship: Boolean = false,
    val fellowship: Boolean = false,
    val rest: Boolean = false,
    val reflection: Boolean = false,
    val characterFocus: String = "",
) {
    fun completedCount(): Int = listOf(word, prayer, worship, fellowship, rest, reflection).count { it }
}

data class Verse(val ref: String, val text: String)

val VERSES = listOf(
    Verse("2 Tim 3:16", "All Scripture is God-breathed and is useful for teaching, rebuking, correcting and training in righteousness."),
    Verse("Ps 119:105", "Your word is a lamp to my feet and a light to my path."),
    Verse("1 Thes 5:17", "Pray without ceasing."),
    Verse("Jas 5:16", "The prayer of a righteous person is powerful and effective."),
    Verse("Jn 4:24", "God is spirit, and his worshipers must worship in the Spirit and in truth."),
    Verse("Ps 46:10", "Be still, and know that I am God."),
    Verse("Prov 27:17", "As iron sharpens iron, so one person sharpens another."),
    Verse("Heb 10:24–25", "Let us consider how we may spur one another on toward love and good deeds... not giving up meeting together."),
    Verse("Jn 14:15", "If you love me, keep my commands."),
    Verse("Jas 2:17", "Faith by itself, if it is not accompanied by action, is dead."),
    Verse("Ps 139:23", "Search me, God, and know my heart; test me and know my anxious thoughts."),
    Verse("2 Cor 13:5", "Examine yourselves to see whether you are in the faith."),
    Verse("Eph 2:10", "We are his workmanship, created in Christ Jesus for good works, which God prepared in advance for us to do."),
    Verse("Jas 4:8", "Draw near to God, and He will draw near to you."),
)
