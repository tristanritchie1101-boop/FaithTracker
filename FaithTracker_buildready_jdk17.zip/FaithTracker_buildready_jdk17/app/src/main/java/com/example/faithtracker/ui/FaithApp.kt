
package com.example.faithtracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

@Composable
fun FaithApp() {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) { Text("FaithTracker") }
    }
}
